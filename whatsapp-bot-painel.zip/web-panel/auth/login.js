const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const senhaCorreta = '$2b$10$abc123abc123abc123abcO0MG123abc123abc123abc123abc123a'; // hash da senha 1234

router.post('/login', (req, res) => {
  const senha = req.body.senha;
  if (bcrypt.compareSync(senha, senhaCorreta)) {
    req.session.logado = true;
    res.redirect('/painel');
  } else {
    res.send('Senha incorreta!');
  }
});

module.exports = router;