const express = require('express');
const session = require('express-session');
const app = express();
const loginRoute = require('./auth/login');

app.use(express.urlencoded({ extended: true }));
app.use(session({ secret: 'painelbot', resave: false, saveUninitialized: true }));
app.use(express.static('public'));
app.use('/', loginRoute);

app.get('/painel', (req, res) => {
  if (!req.session.logado) return res.redirect('/');
  res.send('<h1>Painel do Bot</h1><p>Bem-vindo!</p>');
});

app.listen(3000, () => console.log('🌐 Painel rodando em http://localhost:3000'));