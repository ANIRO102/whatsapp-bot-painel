module.exports = {
  name: 'gay',
  description: 'Calcula o nível de gay',
  execute(client, msg) {
    const porcentagem = Math.floor(Math.random() * 101);
    msg.reply(`🏳️‍🌈 Você é ${porcentagem}% gay!`);
  }
};