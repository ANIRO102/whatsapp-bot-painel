const { Sticker } = require('wa-sticker-formatter');

module.exports = {
  name: 'fig',
  description: 'Transforma imagem em figurinha',
  async execute(client, msg) {
    if (!msg.hasMedia) return msg.reply('Envie uma imagem com o comando.');
    const media = await msg.downloadMedia();
    const sticker = new Sticker(media.data, {
      pack: 'Bot',
      author: 'Dev',
      type: Sticker.Types.FULL,
    });
    const buffer = await sticker.toBuffer();
    client.sendMessage(msg.from, buffer, { sendMediaAsSticker: true });
  }
};