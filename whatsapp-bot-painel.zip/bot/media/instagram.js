const axios = require('axios');

module.exports = {
  name: 'insta',
  description: 'Baixa foto ou vídeo do Instagram',
  async execute(client, msg, args) {
    const url = args[0];
    if (!url || !url.includes('instagram.com')) return msg.reply('Envie um link válido do Instagram.');
    try {
      const response = await axios.get(`https://api.example.com/download?url=${url}`);
      if (response.data.media) {
        client.sendMessage(msg.from, { url: response.data.media }, { caption: 'Aqui está sua mídia!' });
      } else {
        msg.reply('Não foi possível baixar a mídia.');
      }
    } catch (err) {
      msg.reply('Erro ao baixar o conteúdo.');
    }
  }
};