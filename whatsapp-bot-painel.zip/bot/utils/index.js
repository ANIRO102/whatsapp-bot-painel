module.exports = {
  log: (msg) => console.log('[BOT]', msg)
};