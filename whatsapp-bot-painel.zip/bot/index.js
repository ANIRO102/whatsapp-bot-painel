const { default: makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const commands = {};

function loadCommands() {
  const commandFolders = fs.readdirSync('./bot/commands');
  for (const folder of commandFolders) {
    const commandFiles = fs.readdirSync(`./bot/commands/${folder}`).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
      const command = require(`./commands/${folder}/${file}`);
      commands[command.name] = command;
    }
  }
}

async function startBot() {
  const { state, saveState } = useSingleFileAuthState('./auth.json');
  const client = makeWASocket({ auth: state });

  client.ev.on('creds.update', saveState);
  client.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;
    const body = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
    const args = body.trim().split(/ +/);
    const commandName = args.shift().toLowerCase().replace('/', '');
    if (commands[commandName]) {
      try {
        await commands[commandName].execute(client, msg, args);
      } catch (e) {
        console.error(e);
        client.sendMessage(msg.key.remoteJid, { text: 'Erro ao executar o comando.' });
      }
    }
  });

  console.log('🤖 Bot iniciado...');
}

loadCommands();
startBot();